# TO DO
[v] logo di login dan page
[v] Min admin page nya di ganti dashbord

[v] login siswa nya fitur nya transaksi dan riwayat pembayaran

[] Login kepala sekolah sama seperti admin di tambah registrasi akun
[] Untuk admin di tambahi fitur terverivikasi ya min
