<?php $__env->startSection('inner-content'); ?>
<?php $__env->startSection('title','Dashboard | Student'); ?>
<?php $__env->startSection('student-title','Payment summary'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <a href=""" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fa-solid fa-money"></i> Total payment: IDR <?php echo e($total_payment->payments_done); ?></a>
</div>

<div class="container card p-5">
    <table class="table">
        <thead>
            <tr>
            <th scope="col">Product Name</th>
            <th scope="col">Product Stock</th>
            <th scope="col">Product Price</th>
            <th scope="col">Product Price</th>
            <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($p->title); ?></td>
                    <td><?php echo e($p->description); ?></td>
                    <td>IDR <?php echo e($p->fee); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($p->deadline)->format('d F Y')); ?></td>

                    <td class="row gap-2">
                        <?php if($p->is_payment_done == '1'): ?>
                            <a class="col-auto btn btn-group" href="">payment done</a>
                        <?php else: ?>
                            <a class="col-auto btn btn-info" href="<?php echo e(route('student.handleStudentPayment', $p->payment_id)); ?>">pay</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\johedotcom\web\laravel\SppPayment\resources\views/student/dashboard.blade.php ENDPATH**/ ?>