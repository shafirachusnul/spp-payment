<?php $__env->startSection('inner-content'); ?>
<?php $__env->startSection('title','Admin List | Headmaster'); ?>
<?php $__env->startSection('admin-title','List of all admin'); ?>
<div class="container card p-5">
    <table class="table">
        <thead>
            <tr>
            <th scope="col">Admin ID</th>
            <th scope="col">Admin Name</th>
            <th scope="col">Admin Email</th>
            </tr>
        </thead>
        <tbody>
                <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($a->id); ?></td>
                        <td><?php echo e($a->name); ?></td>
                        <td><?php echo e($a->email); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\johedotcom\web\laravel\SppPayment\resources\views/admin/adminList.blade.php ENDPATH**/ ?>