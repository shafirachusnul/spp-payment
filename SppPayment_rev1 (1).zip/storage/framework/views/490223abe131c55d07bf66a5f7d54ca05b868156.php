<?php $__env->startSection('inner-content'); ?>
<?php $__env->startSection('title','Dashboard | Admin'); ?>
<?php $__env->startSection('admin-title','Payment dashboard'); ?>

<div class="container card p-5">
    <table class="table">
        <thead>
            <tr>
            <th scope="col">Product Name</th>
            <th scope="col">Product Stock</th>
            <th scope="col">Product Price</th>
            <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
                <tr>
                    <td>test</td>
                    <td>test</td>
                    <td>test</td>
                    <td class="row gap-2">
                        <a class="col-auto btn btn-info" href="">buy</a>
                    </td>
                </tr>

        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\johedotcom\web\laravel\SppPayment\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>