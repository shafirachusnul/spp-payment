<?php $__env->startSection('inner-content'); ?>
<?php $__env->startSection('title','Dashboard | Admin'); ?>
<?php $__env->startSection('admin-title','Payment List'); ?>

<div class="container card p-5">
    <table class="table">
        <thead>
            <tr>
            <th scope="col">Payment ID</th>
            <th scope="col">Payment Title</th>
            <th scope="col">Payment Description</th>
            <th scope="col">Payment Fee</th>
            <th scope="col">Payment Deadline</th>
            <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($p->id); ?></td>
                    <td><?php echo e($p->title); ?></td>
                    <td><?php echo e($p->description); ?></td>
                    <td>IDR <?php echo e($p->fee); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($p->deadline)->format('d F Y')); ?></td>
                    <td class="row gap-2">
                        <a class="col-auto btn btn-group" href="<?php echo e(route('admin.mappingStudent', $p->id)); ?>">mapping</a>
                        <a class="col-auto btn btn-info" href="<?php echo e(route('admin.updatePayment', $p->id)); ?>">update</a>
                        <a class="col-auto btn btn-danger" href="<?php echo e(route('admin.handleDeletePayment', $p->id)); ?>">delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\johedotcom\web\laravel\SppPayment\resources\views/admin/paymentList.blade.php ENDPATH**/ ?>