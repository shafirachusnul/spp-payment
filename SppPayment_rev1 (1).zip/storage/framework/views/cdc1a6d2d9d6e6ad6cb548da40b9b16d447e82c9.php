<?php $__env->startSection('title','Mapping Payment | Admin'); ?>

<?php $__env->startSection('content'); ?>

<section class="vh-100" style="background-color: #508bfc;">
    <div class="container py-5 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                <div class="card shadow-2-strong" style="border-radius: 1rem;">
                    <form method="POST" action="<?php echo e(route('admin.handleInsertPayment')); ?>" class="card-body p-5 text-center">
                        <?php echo csrf_field(); ?>
                        <h3 class="mb-3">Mapping <?php echo e($payment->title); ?></h3>

                        <div class="mb-3">
                            <p><?php echo e($payment->description); ?></p>
                            <p>Deadline <?php echo e(\Carbon\Carbon::parse($payment->deadline)->format('d F Y')); ?></p>
                            <p>IDR <?php echo e($payment->fee); ?></p>
                        </div>

                        <div class="container-fluid">
                            <div class="container card p-5">
                                <table class="table table-responsive">
                                    <thead>
                                        <tr>
                                            <th scope="col">Student Name</th>
                                            <th scope="col">Student Email</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $isMap = false;
                                            ?>
                                            <tr>
                                                <td><?php echo e($s->name); ?></td>
                                                <td><?php echo e($s->email); ?></td>

                                                <td class="row gap-2">
                                                    <?php $__currentLoopData = $payment_headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($s->id == $p->user_id && $payment->id == $p->payment_id): ?>
                                                            <?php
                                                                $isMap = true;
                                                            ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(!$isMap): ?>
                                                            <a class="col-auto btn btn-info" href="<?php echo e(route('admin.handleMappingStudent', ['user_id' => $s->id, 'payment_id' => $payment->id])); ?>">map</a>
                                                        <?php else: ?>
                                                                <a class="col-auto btn btn-danger" href="<?php echo e(route('admin.handleRemoveMappingStudent', ['user_id' => $s->id, 'payment_id' => $payment->id])); ?>">unmap</a>
                                                        <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <p class="mt-4" style="color: #393f81;">Cancel Insertion? <a href="<?php echo e(route('admin.paymentList')); ?>" style="color: #508bfc;">Back to payment list page</a></p>

                    </form>
                </div>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\johedotcom\web\laravel\SppPayment\resources\views/admin/mappingStudent.blade.php ENDPATH**/ ?>