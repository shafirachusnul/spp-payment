<?php $__env->startSection('title','Insert Admin | Headmaster'); ?>

<?php $__env->startSection('content'); ?>

<section class="vh-100" style="background-color: #508bfc;">
    <div class="container py-5 h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-12 col-md-8 col-lg-6 col-xl-5">
          <div class="card shadow-2-strong" style="border-radius: 1rem;">
            <form method="POST" action="<?php echo e(route('admin.handleInsertAdmin')); ?>" class="card-body p-5 text-center">
              <?php echo csrf_field(); ?>
              <h3 class="mb-5">Insert New Admin</h3>

              <div class="form-outline mb-4">
                <input type="name" id="form2Example17" class="form-control form-control-lg" placeholder="name" name="name">
              </div>

              <div class="form-outline mb-4">
                <input type="email" id="form2Example17" class="form-control form-control-lg" placeholder="email" name="email">
              </div>

              <div class="form-outline mb-4">
                <input type="password" id="form2Example27" class="form-control form-control-lg" placeholder="password" name="password"/>
              </div>

              <?php if($errors->any()): ?>
                <div class="alert alert-danger" role="alert" >
                    <?php echo e($errors->first()); ?>

                </div>
              <?php endif; ?>

              <button class="mb-4 btn btn-primary btn-lg btn-block" type="submit">Register Admin</button>

              <p class="" style="color: #393f81;">Cancel Insertion? <a href="<?php echo e(route('admin.adminList')); ?>" style="color: #508bfc;">Back to admin list page</a></p>

            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\johedotcom\web\laravel\SppPayment\resources\views/admin/insertAdmin.blade.php ENDPATH**/ ?>