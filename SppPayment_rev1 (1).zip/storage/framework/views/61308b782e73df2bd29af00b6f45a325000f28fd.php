<?php $__env->startSection('inner-content'); ?>
<?php $__env->startSection('title','Student List | Admin'); ?>
<?php $__env->startSection('admin-title','List of all student'); ?>
<div class="container card p-5">
    <table class="table">
        <thead>
            <tr>
            <th scope="col">Student ID</th>
            <th scope="col">Student Name</th>
            <th scope="col">Student Email</th>
            <th scope="col">Student Payment Done</th>
            <th scope="col">Student Total Payment</th>
            </tr>
        </thead>
        <tbody>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($s->id); ?></td>
                        <td><?php echo e($s->name); ?></td>
                        <td><?php echo e($s->email); ?></td>
                        <td>IDR <?php echo e($s->payments_done); ?></td>
                        <td>IDR <?php echo e($s->total_fee); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\johedotcom\web\laravel\SppPayment\resources\views/admin/studentList.blade.php ENDPATH**/ ?>