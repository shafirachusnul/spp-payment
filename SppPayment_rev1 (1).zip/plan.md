# page
[] login
[] register

# student 
[] student payment
[] student notification (late notified)

# admin 
[] payment list
[] payment mapping
[] create payment
[] student
[] insert student

# table
[] user
[] payment
[] notification
